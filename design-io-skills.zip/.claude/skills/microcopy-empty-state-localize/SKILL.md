---
name: microcopy-empty-state-localize
description: Refuses to invent content; asks for the real values when they're missing.
category: content
---

# microcopy-empty-state-localize

## When to use
Trigger this skill when the task involves content work on an existing
codebase, or when copying a reference design into a new implementation.

## Steps
1. Read the relevant files before proposing anything.
2. Extract or confirm the design tokens (color, type, spacing, radius, motion).
3. Apply the change in the smallest number of files that can work.
4. Verify in the browser, then report what changed and what was left alone.

## Rules
- Never hardcode colors in components; use semantic tokens.
- Keep composition identical to the reference unless asked otherwise.
- Prefer subtraction over adding new sections.
